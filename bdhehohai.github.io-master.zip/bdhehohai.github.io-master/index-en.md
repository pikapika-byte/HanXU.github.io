<div>
<table border="0">
  <tr>
    <td>
      <h1>Zhang San</h1>
      <p><b>Master</b></p>
      <p><b>College of ××, ×× University</b></p>
      <p><b>E-mail：1234567789@qq.com</b></p>
      <p><b>Address：Rm××, ×× Building, ×× University, ×× Road, Nanjing</b></p>
      <a href="/index.html">中文版</a>
    </td>
    <td width="25%">
      <img src="/zhengjianzhao.jpg" width="100%">
    </td>
  </tr>
</table>
</div>
